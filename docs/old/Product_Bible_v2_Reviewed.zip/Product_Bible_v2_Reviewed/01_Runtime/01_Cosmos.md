# Cosmos

## Purpose

Cosmos is the central environment of the operating system.

It provides the spatial overview of the user's personal universe and serves as the primary entry point into every Project.

Unlike traditional applications, Cosmos is not a collection of pages.

It is one continuous world.

---

# Responsibilities

Cosmos is responsible for:

- global navigation
- Project visualization
- spatial organization
- orientation
- Context transitions
- relationship visualization
- Theme rendering
- access to the Base

Cosmos supports two working modes.

Direct Tool Mode allows one User Tool to open beside the visible map for focused work without leaving Cosmos.

Workspace Mode provides a multi-window environment for complex work involving several Tools.

Cosmos itself does not own editing logic. Every action is still performed by a Tool.

---

# Spatial Environment

Cosmos represents Projects as visible structures inside one shared universe.

Projects are not isolated windows.

They coexist within the same environment.

Users freely navigate through this space using:

- Pan
- Zoom
- Focus
- Quick Travel

The environment continuously maintains spatial orientation.

---

# Projects

Every Project exists as its own constellation.

A Project contains its own internal Node structure.

Projects may be freely positioned.

Their position becomes part of the user's long-term mental map.

Cosmos never reorganizes Projects automatically.

---

# Constellations

Each Project is visualized as a constellation.

Constellations represent structure rather than storage.

Nodes represent Objects.

Connections represent Relationships.

The visual structure should help users understand complexity without exposing technical implementation.

---

# Nodes

Nodes provide direct access to Objects.

They may represent:

- categories
- branches
- objects
- systems
- folders
- important entry points

Nodes visualize meaning.

They never replace the underlying Object.

---

# Navigation

Navigation always preserves orientation.

Supported navigation methods include:

- free exploration
- search
- Companion guidance
- Quick Travel
- object references
- workspace shortcuts

Users should always understand where they are.

---

# Focus

Focusing a Project changes the active Context.

The surrounding universe remains visible.

Only the active Project becomes the current working context.

Focus never disconnects the user from Cosmos.

---

# Context

Cosmos initiates Context inheritance.

Context flows through the Runtime:

Project

↓

Room

↓

Workspace

↓

Tool

↓

Object

Project Context is optional.

When a Project is focused, it becomes the primary Context for newly opened Tools and Workspaces.

Without a focused Project, Cosmos provides global Context.

---

# Direct Tool Mode

A focused Project or Object may open one User Tool directly beside the map.

This mode preserves the constellation and surrounding Project structure while the user performs one focused task.

Opening additional Tools or arranging multiple windows transitions the user into a Workspace.

Direct Tool Mode and Workspace Mode use the same Tool definitions, Runtime Services and Context model.

# Base

The Base permanently accompanies the user.

It represents the user's home.

The Base provides access to:

- Rooms
- Workspaces
- Companion
- personal configuration

The visual appearance of the Base depends entirely on the active Theme.

---

# Themes

Themes define the visual interpretation of Cosmos.

A Theme may replace:

- background
- Base
- Rooms
- Nodes
- connectors
- animations
- effects
- companion appearance
- project appearance

Every component may also be individually overridden.

Themes never change functionality.

---

# Level of Detail

Cosmos continuously adjusts visual complexity.

Zooming out emphasizes Projects.

Zooming in gradually reveals:

- branches
- Objects
- Relationships
- details

The user should never lose orientation regardless of zoom level.

---

# Relationships

Relationships appear as constellation lines.

Version 1 distinguishes:

- Structural Relationships
- Discovered Relationships

Structural Relationships represent intentional organization.

Discovered Relationships visualize meaningful patterns found by Cosmos.

Discovered Relationships never modify the user's structure automatically.

---

# Companion

The Companion accompanies the user everywhere.

Inside Cosmos, the Companion serves as navigator, guide and discussion partner.

The Companion helps discover Projects, Objects and relationships without interrupting the user's workflow.

---

# Search

Global search belongs to the Archive.

Cosmos simply provides entry points into that information.

Search results may reference:

- Projects
- Objects
- Knowledge
- Resources
- Workspaces

Opening a result always preserves Context.

---

# Extensibility

Cosmos is designed to grow.

Future extensions may introduce:

- additional Themes
- new visualization styles
- alternative Node skins
- new navigation methods
- collaborative experiences
- future spatial concepts

Extensions should integrate into Cosmos without changing its fundamental principles.

---

# Design Goal

Cosmos should feel like a living universe that evolves together with its user.

Instead of navigating through applications, users navigate through their own knowledge, projects and creations.

The environment should encourage exploration, understanding and long-term thinking.

---

# Principles

- Cosmos is the root environment.
- Projects exist as constellations.
- Nodes visualize Objects.
- Orientation is always preserved.
- Themes only change appearance.
- Context begins inside Cosmos.
- Focused work may happen through one Tool beside the map or through a multi-window Workspace.
- Cosmos grows together with its user.
