# Registry System

## Purpose

The Registry System defines how Cosmos discovers, identifies and exposes available Runtime components.

Registries provide one authoritative source for everything that can be loaded or used by the Runtime.

They answer one question:

What is available?

---

# Philosophy

Cosmos should never depend on hardcoded lists of Tools, Themes, Providers or Blueprints.

Every extensible component registers itself through a Registry.

The Core knows contracts.

Registries know implementations.

This allows new capabilities to be added without changing Core logic.

---

# Responsibilities

The Registry System is responsible for:

- registering Runtime components
- validating component identity
- resolving components by ID
- exposing component metadata
- preventing duplicate registrations
- tracking availability
- supporting activation and deactivation
- preserving stable references

Registries do not execute component behavior.

They only manage component definitions.

---

# Registry Categories

Cosmos uses specialized Registries built on one shared Registry contract.

Initial Registries include:

- Extension Registry
- User Tool Registry
- System Tool Registry
- Theme Registry
- Skin Registry
- Workspace Blueprint Registry
- Object Blueprint Registry
- Capture Template Registry
- Provider Registry
- Integration Registry

Future Registry categories may be added without changing the general Registry model.

---

# Registry Entry

Every registered component is represented by a Registry Entry.

A Registry Entry contains:

- immutable component ID
- display name
- component category
- version
- Runtime API version
- source Extension
- current status
- capabilities
- dependencies
- permissions
- configuration schema
- entry point
- metadata

Registry Entries describe components.

They do not contain active component state.

---

# Identity

Every registered component requires one globally unique and immutable ID.

Example:

```text
cosmos.user-tool.capture
cosmos.system-tool.knowledge-processor
cosmos.theme.galaxy
cosmos.provider.codex
Display names may change.

Component IDs never change.

References always use component IDs rather than display names.

Namespaces

Component IDs use namespaces.

Namespaces prevent collisions between bundled, user-created and third-party Extensions.

Recommended format:

<owner>.<category>.<component>

Examples:

cosmos.user-tool.archive
cosmos.theme.galaxy
max.workspace-blueprint.mettventures
community.user-tool.voxel-editor

Cosmos reserves the cosmos namespace for bundled components.

Registration

Registration occurs only after successful Extension validation.

The general lifecycle is:

Extension Discovery

↓

Manifest Validation

↓

Dependency Resolution

↓

Component Registration

↓

Runtime Availability

A component that fails validation is never added to an active Registry.

Duplicate Registration

Duplicate component IDs are not permitted.

If two components attempt to register the same ID:

the bundled Core is never silently replaced
the later component is rejected
the conflict is logged
the user receives a clear explanation

Overrides must use an explicit override mechanism.

They must never happen accidentally.

Overrides

Cosmos supports controlled visual and configuration overrides.

Examples include:

replacing a Skin
overriding a Theme component
changing a Workspace Blueprint default
replacing a Provider configuration

Overrides do not change the identity of the original component.

They create a new configuration layer that references the original Registry Entry.

Functional components are not replaced silently.

Registry Status

A Registry Entry may have one of the following states:

Discovered
Validated
Registered
Active
Disabled
Incompatible
Missing Dependency
Failed

Only Active entries may be instantiated or executed.

Activation

Registration and activation are separate.

A component may be registered but disabled.

This allows users to:

install Extensions
inspect metadata
review permissions
activate later
disable without uninstalling

Activation is controlled by the Runtime.

Resolution

Runtime components are resolved by immutable ID.

Example:

Workspace requests:

cosmos.user-tool.capture

The Tool Registry resolves the current compatible definition.

Consumers never import Extension internals directly.

They request components through Runtime Services.

Dependencies

Registry Entries may declare dependencies.

Dependencies reference immutable component IDs and compatible version ranges.

Example:

cosmos.user-tool.blueprint-builder

requires:

cosmos.system-tool.runtime-translation >= 1.0

The Registry System validates dependencies before activation.

Circular dependencies are rejected.

Capabilities

Registry Entries declare capabilities.

Examples include:

creates Knowledge
edits image Resources
supports Object Blueprints
provides AI completion
renders Node Skins
analyzes repositories

Capabilities allow the Runtime to discover suitable components without knowing their implementation.

Queries

Registries support read-only discovery queries.

Examples include:

list all User Tools
find Tools supporting image Resources
find Themes containing Companion Skins
find Providers supporting code generation
find Blueprints compatible with the active Project

Registry queries never execute components.

Runtime State

Registries store component definitions.

They do not store active Tool Instance state, Workspace layouts or running Jobs.

Runtime state belongs to the corresponding Runtime systems.

This separation keeps Registries predictable and lightweight.

Persistence

Registry metadata may be cached for startup performance.

The authoritative definition remains the Extension Manifest and validated component declaration.

Cached Registry state may always be rebuilt.

User activation choices and configuration overrides are persistent data.

Failure Handling

One invalid component must never prevent Cosmos from starting.

If registration fails:

the affected component is isolated
the failure is recorded
dependent components are marked unavailable
unrelated components continue loading
the user receives actionable information
Extensibility

Every future extensible component category should use the shared Registry contract.

New Registries may introduce category-specific metadata while preserving:

stable identity
validation
status
activation
dependency resolution
capability discovery
Design Goal

The Registry System should make Cosmos feel infinitely expandable without making the Core aware of every possible capability.

The Runtime should always know what exists, what is compatible and what may safely be used.

Principles
Every extensible component is registered.
Registries manage definitions, not execution.
IDs are immutable.
Display names are editable.
Registration follows validation.
Activation is explicit.
Duplicate IDs are rejected.
Components are resolved through the Runtime.
One failed component never breaks Cosmos.
Every Registry follows one shared contract.
